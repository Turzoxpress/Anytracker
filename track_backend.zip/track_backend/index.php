	<?php


if (isset($_GET["p"])) {
    
    if ($_GET["p"] == "register") {
        
        registerUser();
        
    }else if ($_GET["p"] == "update") {
        
        updateUserData();
        
    }else if ($_GET["p"] == "delete") {
        
        deleteUserData();
        
    }else if ($_GET["p"] == "getdata") {
        
        getData();
    }
    
} else {
    echo "Not Found";
    
}


function registerUser()
{
    
    
    
    require_once("config.php");
    $input      = @file_get_contents("php://input");
    $event_json = json_decode($input, true);
    //print_r($event_json);
    
    
    if (isset($event_json['code']) && isset($event_json['user_name'])) {
        $code      = $event_json['code'];
        $user_name = $event_json['user_name'];
        $user_lat  = $event_json['user_lat'];
        $user_long = $event_json['user_long'];
        
        //	print_r($event_json);
        
        $result   = mysqli_query("SELECT * FROM data WHERE code='$code' LIMIT 1");
        $num_rows = mysqli_num_rows($result);
        
        //--
        $q   = "SELECT COUNT(1) FROM data WHERE code='$code'";
        $r   = mysqli_query($conn, $q);
        $row = mysqli_fetch_row($r);
        
        
        if ($row[0] >= 1) {
            //print "Record exists";
            $array_out = array();
            
            $array_out[] = array(
                "response" => "Data already exists"
            );
            
            $output = array(
                "code" => "201",
                "msg" => $array_out
            );
            print_r(json_encode($output, true));
            
        } else {
            
            //--
            
            //--
            $qrry_1 = "insert into data(code,name,user_lat,user_long)values(";
            $qrry_1 .= "'" . $code . "',";
            $qrry_1 .= "'" . $user_name . "',";
            $qrry_1 .= "'" . $user_lat . "',";
            $qrry_1 .= "'" . $user_long . "'";
            $qrry_1 .= ")";
            if (mysqli_query($conn, $qrry_1)) {
                
                //echo "Data inserted successfully!";
                
                $array_out = array();
                
                $array_out[] = array(
                    "response" => "Data inserted successfully"
                );
                
                $output = array(
                    "code" => "200",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
                
            } else {
                
                echo mysqli_error($conn);
            }
            
            
            
            //---------------
            
            
            //------------------
            
        }
        
        
        
    }
    
    mysqli_close($conn);
    
    
    
}

function updateUserData()
{
    
    
    
    require_once("config.php");
    $input      = @file_get_contents("php://input");
    $event_json = json_decode($input, true);
    //print_r($event_json);
    
    
    if (isset($event_json['code']) && isset($event_json['user_name'])) {
        $code      = $event_json['code'];
        $user_name = $event_json['user_name'];
        $user_lat  = $event_json['user_lat'];
        $user_long = $event_json['user_long'];
        
        //	print_r($event_json);
        
        $sql = "UPDATE data SET name='$user_name',user_lat='$user_lat',user_long='$user_long' WHERE code='$code'";
        
        if (mysqli_query($conn, $sql)) {
            
            //echo "Data updated successfully";
            
            $array_out = array();
            $array_out = array();
                
                $array_out[] = array(
                    "response" => "Data updated successfully"
                );
                
                $output = array(
                    "code" => "200",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
            
        }else{
            
            // echo mysqli_error($conn);
             $array_out = array();
            $array_out = array();
                
                $array_out[] = array(
                    "response" => mysqli_error($conn)
                );
                
                $output = array(
                    "code" => "201",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
            
        }
        
        
        
        
    }
    
    mysqli_close($conn);
    
    
    
}


function deleteUserData()
{
    
    
    
    require_once("config.php");
    $input      = @file_get_contents("php://input");
    $event_json = json_decode($input, true);
    //print_r($event_json);
    
    
    if (isset($event_json['code'])) {
        $code      = $event_json['code'];
       // $user_name = $event_json['user_name'];
       // $user_lat  = $event_json['user_lat'];
       // $user_long = $event_json['user_long'];
        
        //	print_r($event_json);
        
        $sql = "DELETE from data WHERE code='$code'";
        
        if (mysqli_query($conn, $sql)) {
            
            //echo "Data updated successfully";
            
            $array_out = array();
            $array_out = array();
                
                $array_out[] = array(
                    "response" => "Data deleted successfully"
                );
                
                $output = array(
                    "code" => "200",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
            
        }else{
            
            // echo mysqli_error($conn);
             $array_out = array();
            $array_out = array();
                
                $array_out[] = array(
                    "response" => mysqli_error($conn)
                );
                
                $output = array(
                    "code" => "201",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
            
        }
        
        
        
        
    }
    
    mysqli_close($conn);
    
    
    
}

function getdata()
{
    
    
    
    require_once("config.php");
    $input      = @file_get_contents("php://input");
    $event_json = json_decode($input, true);
    //print_r($event_json);
    
    
    if (isset($event_json['code'])) {
        $code      = $event_json['code'];
       // $user_name = $event_json['user_name'];
       // $user_lat  = $event_json['user_lat'];
       // $user_long = $event_json['user_long'];
        
        //	print_r($event_json);
        
         //--
        $q   = "SELECT COUNT(1) FROM data WHERE code='$code'";
        $r   = mysqli_query($conn, $q);
        $row = mysqli_fetch_row($r);
        
        $array_out = array();
        
        
        if ($row[0] >= 1) {
            //print "Record exists";
            
            //--
             
        $sql = "SELECT name,user_lat,user_long from data WHERE code='$code'";
        $result = mysqli_query($conn, $sql);
        
        while ($row=mysqli_fetch_row($result))
                    {
           //printf ("%s (%s)\n",$row[0],$row[1]);
           $array_out[] = array(
                    "user_name" => $row[0],
                    "user_lat" => $row[1],
                    "user_long" => $row[2],
                );
                
                 $output = array(
                    "code" => "200",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
                
                
       
        
                    }
            
            
            //----------
            
            
        } else {
            
             $array_out = array();
                
                $array_out[] = array(
                    "response" => "No ID found!"
                );
                
                $output = array(
                    "code" => "201",
                    "msg" => $array_out
                );
                print_r(json_encode($output, true));
            
            
        }
        
        
       
        
        
       
    }
    
    mysqli_close($conn);
    
    
    
}



?>

