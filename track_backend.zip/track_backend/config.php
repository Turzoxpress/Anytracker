<?php
	

	
	
	//database configration
	$servername = "localhost";
	$database = "newgenbd_job";
	$username = "newgenbd_turzo";
	$password = "MZ6Z@&oI1TWp";
    
	// Create connection

	$conn = mysqli_connect($servername, $username, $password, $database);

	// Check connection

	if (!$conn) {

	    die("Connection failed: " . mysqli_connect_error());

	}else{
	    
	    //echo 'database connected!';
	}
    
	
?>